### 1.概述<!-- {docsify-ignore-all} -->

​	`文件解析管理`用于管理和维护pcap包，主要包含：pcap包查询、上传、修改、删除等功能。

​	下面将详细介绍`文件解析管理`功能的使用与说明。![](./img/01-pcap包管理首页.png)



- [1.pcap包查询](/zh-cn/parse/pcapQuery)
- [2.pcap包管理](/zh-cn/parse/pcapManage)

