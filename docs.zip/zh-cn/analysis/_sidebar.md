<!-- docs/_sidebar.md --> 

- [pcap综合分析](/zh-cn/analysis/overview)
  * [概述](zh-cn/analysis/overview) 
  * [工程管理](/zh-cn/analysis/project)
  * [收藏的查询](/zh-cn/analysis/query)
  * [分析类型统计概要](zh-cn/analysis/statInfo) 
  * [吞吐量概要](zh-cn/analysis/throughput) 
  * [连接情况概要](zh-cn/analysis/connection) 
  * [网络性能概要](zh-cn/analysis/net) 
  * [应用性能概要](zh-cn/analysis/appInfo) 
  * [http指标概要](zh-cn/analysis/http) 
  * [流量分析](zh-cn/analysis/flow) 
  * [应用日志](zh-cn/analysis/appLog) 
  * [PCAP分析](zh-cn/analysis/pcap) 
  * [折叠/展开](zh-cn/analysis/window) 
  * [全局设置](zh-cn/analysis/setting) 

