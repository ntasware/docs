### 1.概述<!-- {docsify-ignore-all} -->

​	流量查询是通过探针查询到的采集数据，NTAS为用户提供多种组合条件查询，包含：维度、指标等，最终显示数据并为后续解析提供数据支撑。



- [查询列表](/zh-cn/query/list)

- [查询条件](/zh-cn/query/criteria)
- 

